#ifndef DEBUG_H
#define DEBUG_H

#include <iostream>
//#include <QString>

//#define DEBUG(msg) std::cout << msg << std::endl; std::cout.flush();
#define DEBUG(msg)

#endif // DEBUG_H
